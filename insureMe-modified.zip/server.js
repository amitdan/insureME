const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const app = express()

const apiKey = '*****************';

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs')

app.get('/', function (req, res) {
  res.render('index', {weather: null, error: null});
})

app.post('/', function (req, res) {
  let city = req.body.city;
  let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=imperial&appid=${apiKey}`

  request(url, function (err, response, body) {
    if(err){
      res.render('index', {weather: null, error: 'Error, please try again'});
    } else {
      let weather = JSON.parse(body)
      if(weather.main == undefined){
        res.render('index', {weather: null, error: 'Error, please try again'});
      } else {
        let weatherText = `It's ${weather.main.temp} degrees in ${weather.name}!`;
        res.render('index', {weather: weatherText, error: null});
      }
    }
  });
})

app.post('/getQuatation', function (req, res) {

 var solartisRequest = {
  "ServiceRequestDetail": {
    "ServiceRequestVersion": "1.0",
    "ServiceResponseVersion": "1.0",
    "OwnerId": "15",
    "ResponseType": "JSON",
    "RegionCode": "US",
    "Token": "FK8KA9to4/LHKyC28Rsv0wR9i5j3dnrwGQRILW/8MkzAuWoimT7wulJVg3cS+2dW9GeGoqnrLT3ZN44dzwztduSs7X/MgcZvxiqxWRpCzolF8RMcGIsESQs7AvCtLKn7+Pi5HjyBGO/2LwQrVBFGX1sp9faSYo8bbtX89ENdEREse4y3Z1niXChJtel6E5IxhB12xYX8R+5jZevfvFIHMZdk6lkxyHedo2UipPyjN+0mdf87C6sQG8h1r6hKb04LEmXZ1BU3jF61VNK/GgaduY0lMmPL81e6nEBkcH0KIlXTUMLZLozOdpnetxAq8wLxtseNSFd530pMt9CYTG99SFRnH8sd+BgM0Rez5x1HXtJsxmmSocsu7aM6X7h4tRI09ja6eS3YMndyPUCaAIX4r08rFmfeJE/yhxYdN9OrrhKegiqZ0Z5sPWeMUdYjij7ERCWiYO/sCHW7A2SCkiheEh1e/+iRPwub5Etbe6/jv0QHhMUvhbV+fxBIwMZ+h/TpdXaLdBpz+LcK6o/vVDiC7BiJ+X1o/O6u9Bmft39DqDNBPRtZCVXFbjPc6tSBtCqZda6debd6ih5Q7LFl2i3rpMQNYWbPB5hFVVTalEXW8lomy7ibLpvGe50CpdYqy2uiTuDEV2nQK2443AFbAUZkMkSImQ2OLrfqscPDhCdD6wJN3d9rGqIh12WiBMlsHlrYrfN2cawRumUC96m1/sMIK6GPUyTndDmrV0xIXWepGqyW+Q76nzG+KT2qKJ/TT3J4OruCnE4ELmCGfaAD6J6w4ajfyw0ctYsjrnfufI5R4B/gco9z18dSe5OXowbwGT55td9YyEXuURYw4ubWb2LxHFRpYSQ3f5fYn0XsvtG5cghuuteDKqd8xbs93+cv+0aTYdPesM+MuKf+6HYItv+4uR5No8N/ar8RkYgBDxofe2yfxb8+Mrg51+uddbuTXIjJQOdhulWKv+0IR0S8sBeteQ==",
    "UserName": "travelagent",
    "LanguageCode": "en"
  },
  "QuoteInformation": {
    "ProductID": "619",
    "ProductVerID": "706",
    "ProductNumber": "ILT",
    "ProductVerNumber": "1.0",
    "ProducerCode": "86201",
    "OwnerId": "15",
    "PlanName": "Air Ticket Protector",
    "PlanCode": "1",
    "DepartureDate": "06/25/2017",
    "ReturnDate": "06/31/2017",
    "DepositDate": "06/03/2017",
    "DestinationCountry": "France",
    "PolicyEffectiveDate": "06/25/2017",
    "RentalStartDate": "06/25/2017",
    "RentalEndDate": "06/31/2017",
    "RentalLimit": "35000",
    "NumberOfRentalCars": "1",
    "TripCancellationCoverage": "With Trip Cancellation",
    "StateCode": "GA",
    "QuoteType": "New Business",
    "EventName": "InvokeRatingV2",
    "TravelerList": [
      {
        "TravelerDOB": "02/14/1990",
        "TravelCost": "2500"
      }
    ]
  }
}

     request.post({
      headers: {
        'Content-Type': 'application/json',
        'EventName': 'InvokeRatingV2',        
        'Token': solartisRequest.ServiceRequestDetail.Token

      },
      url: 'https://travelapihk.solartis.net/DroolsV4_2/DroolsService/FireEventV2',
      body: JSON.stringify(solartisRequest)
    }, (err, httpResponse, body) => {
      if (err) {
        return console.error('err:', err);
        res.send("sorry there was an error");
      }
      console.log('httpResponse.statusCode', httpResponse.statusCode);
      console.log('body: ', body);
      var solartisResponse = JSON.parse(body);
	  
	  let weatherText = `Policy Premium -  ${solartisResponse.PremiumInformation.TotalBasePremium}`;
      res.render('index', {weather: weatherText, error: null});
	  
	  //res.render('index', { statusCode: httpResponse.statusCode, statusMessage: httpResponse.statusMessage });
      });
})


app.post('/issuePolicy', function (req, res) {


  let customerNumber = req.body.customerNumber;
  //let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=imperial&appid=${apiKey}`
  
    
 var solartisRequest = {
  "ServiceRequestDetail": {
    "ServiceRequestVersion": "1.0",
    "ServiceResponseVersion": "1.0",
    "OwnerId": "15",
    "ResponseType": "JSON",
    "RegionCode": "US",
    "Token": "FK8KA9to4/LHKyC28Rsv0wR9i5j3dnrwGQRILW/8MkzAuWoimT7wulJVg3cS+2dW9GeGoqnrLT3ZN44dzwztduSs7X/MgcZvxiqxWRpCzolF8RMcGIsESQs7AvCtLKn7+Pi5HjyBGO/2LwQrVBFGX1sp9faSYo8bbtX89ENdEREse4y3Z1niXChJtel6E5IxhB12xYX8R+5jZevfvFIHMZdk6lkxyHedo2UipPyjN+0mdf87C6sQG8h1r6hKb04LEmXZ1BU3jF61VNK/GgaduY0lMmPL81e6nEBkcH0KIlXTUMLZLozOdpnetxAq8wLxtseNSFd530pMt9CYTG99SFRnH8sd+BgM0Rez5x1HXtJsxmmSocsu7aM6X7h4tRI09ja6eS3YMndyPUCaAIX4r08rFmfeJE/yhxYdN9OrrhKegiqZ0Z5sPWeMUdYjij7ERCWiYO/sCHW7A2SCkiheEh1e/+iRPwub5Etbe6/jv0QHhMUvhbV+fxBIwMZ+h/TpdXaLdBpz+LcK6o/vVDiC7BiJ+X1o/O6u9Bmft39DqDNBPRtZCVXFbjPc6tSBtCqZda6debd6ih5Q7LFl2i3rpMQNYWbPB5hFVVTalEXW8lomy7ibLpvGe50CpdYqy2uiTuDEV2nQK2443AFbAUZkMkSImQ2OLrfqscPDhCdD6wJN3d9rGqIh12WiBMlsHlrYrfN2cawRumUC96m1/sMIK6GPUyTndDmrV0xIXWepGqyW+Q76nzG+KT2qKJ/TT3J4OruCnE4ELmCGfaAD6J6w4ajfyw0ctYsjrnfufI5R4B/gco9z18dSe5OXowbwGT55td9YyEXuURYw4ubWb2LxHFRpYSQ3f5fYn0XsvtG5cghuuteDKqd8xbs93+cv+0aTYdPesM+MuKf+6HYItv+4uR5No8N/ar8RkYgBDxofe2yfxb8+Mrg51+uddbuTXIjJQOdhulWKv+0IR0S8sBeteQ==",
    "UserName": "travelagent",
    "LanguageCode": "en"
  },
  "PolicyInformation": {
    "ProductVerID": "706",
    "ProductID": "619",
    "ProductNumber": "ILT",
    "ProductVerNumber": "1.0",
    "ProducerCode": "86201",
    "OwnerId": "15",
    "CustomerNumber": customerNumber,
    "RoleID": "5",
    "RoleName": "Agent",
    "RoleType": "User",
    "EventName": "Pay_Issue",
    "CardNumber": "5555555555554444",
    "CVV": "123",
    "ExpiryMonth": "11",
    "ExpiryYear": "2018",
    "PayerName": "John Doe",
    "PayerAddress1": "399 Park st",
    "PayerCity": "Atlanta",
    "PayerState": "GA",
    "PayerCountry": "US",
    "PayerZipcode": "30301",
    "PayerEmail": "test@solartis.net",
    "PayerPhone": "4045555512",
    "PaymentMethod": "Credit Card",
    "CardType": "MasterCard"
  }
}

     request.post({
      headers: {
        'Content-Type': 'application/json',
        'EventName': 'Pay_Issue',        
        'Token': solartisRequest.ServiceRequestDetail.Token

      },
      url: 'https://travelapihk.solartis.net/DroolsV4_2/DroolsService/FireEventV2',
      body: JSON.stringify(solartisRequest)
    }, (err, httpResponse, body) => {
      if (err) {
        return console.error('err:', err);
        res.send("sorry there was an error");
      }
      console.log('httpResponse.statusCode', httpResponse.statusCode);
      console.log('body: ', body);	  
      var solartisResponse = JSON.parse(body);
	  if(solartisResponse.RequestStatus == 'FAILED'){
	    let errorResponse = `Response -  ${solartisResponse.messageDetail.UserMessage}`;
        res.render('index', {weather: errorResponse, error: null});
      } else {
        let weatherText = `Customer Reference Number -  ${solartisResponse.CustomerReferenceNumber}, Policy Number -  ${solartisResponse.PolicyBatch.Policies[0].PolicyNumber}, Policy Premium -  ${solartisResponse.PolicyBatch.TotalPolicyPremium}`;
        res.render('index', {weather: weatherText, error: null});
      }	  
      });
})

app.post('/createCustomer', function (req, res) {

 var solartisRequest = {
  "ServiceRequestDetail": {
    "ServiceRequestVersion": "1.0",
    "ServiceResponseVersion": "1.0",
    "OwnerId": "15",
    "ResponseType": "JSON",
    "RegionCode": "US",
    "Token": "FK8KA9to4/LHKyC28Rsv0wR9i5j3dnrwGQRILW/8MkzAuWoimT7wulJVg3cS+2dW9GeGoqnrLT3ZN44dzwztduSs7X/MgcZvxiqxWRpCzolF8RMcGIsESQs7AvCtLKn7+Pi5HjyBGO/2LwQrVBFGX1sp9faSYo8bbtX89ENdEREse4y3Z1niXChJtel6E5IxhB12xYX8R+5jZevfvFIHMZdk6lkxyHedo2UipPyjN+0mdf87C6sQG8h1r6hKb04LEmXZ1BU3jF61VNK/GgaduY0lMmPL81e6nEBkcH0KIlXTUMLZLozOdpnetxAq8wLxtseNSFd530pMt9CYTG99SFRnH8sd+BgM0Rez5x1HXtJsxmmSocsu7aM6X7h4tRI09ja6eS3YMndyPUCaAIX4r08rFmfeJE/yhxYdN9OrrhKegiqZ0Z5sPWeMUdYjij7ERCWiYO/sCHW7A2SCkiheEh1e/+iRPwub5Etbe6/jv0QHhMUvhbV+fxBIwMZ+h/TpdXaLdBpz+LcK6o/vVDiC7BiJ+X1o/O6u9Bmft39DqDNBPRtZCVXFbjPc6tSBtCqZda6debd6ih5Q7LFl2i3rpMQNYWbPB5hFVVTalEXW8lomy7ibLpvGe50CpdYqy2uiTuDEV2nQK2443AFbAUZkMkSImQ2OLrfqscPDhCdD6wJN3d9rGqIh12WiBMlsHlrYrfN2cawRumUC96m1/sMIK6GPUyTndDmrV0xIXWepGqyW+Q76nzG+KT2qKJ/TT3J4OruCnE4ELmCGfaAD6J6w4ajfyw0ctYsjrnfufI5R4B/gco9z18dSe5OXowbwGT55td9YyEXuURYw4ubWb2LxHFRpYSQ3f5fYn0XsvtG5cghuuteDKqd8xbs93+cv+0aTYdPesM+MuKf+6HYItv+4uR5No8N/ar8RkYgBDxofe2yfxb8+Mrg51+uddbuTXIjJQOdhulWKv+0IR0S8sBeteQ==",
    "UserName": "travelagent",
    "LanguageCode": "en"
  },
  "CustomerInformation": {
    "ProductVerID": "706",
    "ProductID": "619",
    "ProductNumber": "ILT",
    "ProductVerNumber": "1.0",
    "ProducerCode": "86201",
    "OwnerId": "15",
    "PlanName": "Air Ticket Protector",
    "PlanCode": "1",
    "PlanType": "Single Trip",
    "DepartureDate": "11/01/2020",
    "ReturnDate": "11/25/2020",
    "DepositDate": "05/31/2017",
    "DestinationCountry": "France",
    "PolicyEffectiveDate": "11/01/2020",
    "StateCode": "GA",
    "StateName": "Georgia",
    "QuoteType": "New Business",
    "EventName": "CreateCustomer",
    "TravelerList": [
      {
        "TravelerDOB": "02/14/1990",
        "TravelCost": "2500",
        "FirstName": "John",
        "LastName": "Doe",
        "AddressLine1": "399 park avenue",
        "City": "Atlanta",
        "State": "Georgia",
        "StateCode": "GA",
        "Country": "United States",
        "Zipcode": "30301",
        "Phone": "4045555512",
        "Email": "test@solartis.net",
        "TravelerIndex": "1"
      }
    ]
  }
}

     request.post({
      headers: {
        'Content-Type': 'application/json',
        'EventName': 'CreateCustomer',        
        'Token': solartisRequest.ServiceRequestDetail.Token

      },
      url: 'https://travelapihk.solartis.net/DroolsV4_2/DroolsService/FireEventV2',
      body: JSON.stringify(solartisRequest)
    }, (err, httpResponse, body) => {
      if (err) {
        return console.error('err:', err);
        res.send("sorry there was an error");
      }
      console.log('httpResponse.statusCode', httpResponse.statusCode);
      console.log('body: ', body);
      var solartisResponse = JSON.parse(body);
	  if(solartisResponse.RequestStatus == 'FAILED'){
	    let errorResponse = `Response -  ${solartisResponse.messageDetail.UserMessage}`;
        res.render('index', {weather: errorResponse, error: null});
      } else {
        let weatherText = `Customer Reference Number -  ${solartisResponse.CustomerInformation.CustomerReferenceNumber}`;
        res.render('index', {weather: weatherText, error: null});
      }	  
      });
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})
